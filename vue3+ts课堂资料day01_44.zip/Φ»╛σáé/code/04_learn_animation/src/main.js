import { createApp } from 'vue'
import App from './03_列表动画的使用/02_列表的交替动画.vue'
import "animate.css";

createApp(App).mount('#app')
