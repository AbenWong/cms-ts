let flag: boolean = true
flag = 20 > 30
