const info = {
  name: "why",
  age: 18
}

console.log(info.name)
