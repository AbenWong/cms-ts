// interface IFoo {
//   name: string
// }

// interface IFoo {
//   age: number
// }

// const foo: IFoo = {
//   name: "why",
//   age: 18
// }

// document.getElementById("app") as HTMLDivElement
// window.addEventListener

// interface Window {
//   age: number
// }
// window.age = 19
// console.log(window.age)


// type IBar = {
//   name: string
//   age: number
// }

// type IBar = {
// }

interface IPerson {
  
}
