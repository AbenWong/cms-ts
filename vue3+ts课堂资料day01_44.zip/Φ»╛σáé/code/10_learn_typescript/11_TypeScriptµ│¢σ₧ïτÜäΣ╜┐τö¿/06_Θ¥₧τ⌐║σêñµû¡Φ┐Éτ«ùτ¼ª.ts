const flag = "" ?? true
console.log(flag)
