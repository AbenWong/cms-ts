<template>
  <div>
    <home message="hahahaha" id="aaa" class="bbbb"></home>
  </div>
</template>

<script>
  import Home from './Home.vue';

  export default {
    components: {
      Home
    }
  }
</script>

<style scoped>

</style>